using namespace std::vector;    

using std::cout;
asm ("ms_codsx0");
namespace namespace_name {
   // code declarations
}
//using std::vector::test::test::test::test::test::test;
//using aa = idset;
//int a = 10;
//auto f = [&tst, temp](int a, char* k) -> void {
//    int ak = 10;
//    ak += 10;
//    a++;
//    funcA(ak);
//    return;
////};

//function to push the item 
//enum day2 ;
/*
inline void push() {
    int top;
    top++;
    for(int a=0, j=10, k = 10- 4; a< 10; a++){
        
    }

}
//
////function to perform the operation depending on the operator.
int operation(int a,int b,char opr) {
    int a = 10;
    switch(opr) {
        case '+':return a+b;
        case '-':return a-b;
        case '*':return a*b;
        case '/':return a/b;
        default: return 0;
    }
}

int getFileLineCount(const char* paramFilename){
	int count;
    if(paramFile.is_open()){
        while(paramFile.good()){
            getline(paramFile, line);
			count ++;
        }
        paramFile.close();
    }
    return count;
}

int iscolon(int c){
    if((char)c == ':')
        return 1;
    else
        return 0;
}

int ispathseperator(int c){
    if((char)c == '/')
        return 1;
    else
        return 0;
}

int isDot(int c){
    if((char)c == '.')
        return 1;
    else
        return 0;
}
*/