package com.mycompany.packagetest;

public final class ClassExtendsTest extends ClassTest {
}
