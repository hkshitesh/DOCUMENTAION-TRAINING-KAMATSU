package com.mycompany.packagetest;

public class FieldMultipleVariablesTest {

    int field1, field2, field3, field4;

}
