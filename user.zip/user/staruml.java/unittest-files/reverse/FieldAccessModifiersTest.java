package com.mycompany.packagetest;

public class FieldAccessModifiersTest {
    
    public int publicField;
    
    protected int protectedField;
    
    private int privateField;
    
    int packageField;
    
}
