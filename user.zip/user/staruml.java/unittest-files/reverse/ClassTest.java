package com.mycompany.packagetest;

public class ClassTest {
}
