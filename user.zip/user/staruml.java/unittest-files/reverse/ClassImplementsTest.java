package com.mycompany.packagetest;

public final class ClassImplementsTest implements InterfaceTest {
}
