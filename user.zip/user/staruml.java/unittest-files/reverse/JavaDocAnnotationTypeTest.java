package com.mycompany.packagetest;

/**
 * JavaDoc for AnnotationType
 */
@interface JavaDocAnnotationTypeTest {
    
    /**
     * JavaDoc for AnnotationTypeElement1
     */
    String javaDocAnnotationTypeElement1();

    /**
     * JavaDoc for AnnotationTypeElement2
     */
    String javaDocAnnotationTypeElement2();
    
}
